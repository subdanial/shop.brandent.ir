<?php

class LP_Certificates_Settings extends LP_Abstract_Settings_Page {
	/**
	 * Constructor
	 */
	public function __construct() {
		$this->id   = 'certificates';
		$this->text = __( 'Certificates', 'edali-toolkit' );

		parent::__construct();
	}

	public function get_settings( $section = '', $tab = '' ) {
		return array(
			array(
				'title'   => __( 'Google Fonts', 'edali-toolkit' ),
				'id'      => 'certificates[google_fonts]',
				'default' => 'no',
				'type'    => 'google-fonts'
			),
			array(
				'name'            => __( 'Social Sharing', 'edali-toolkit' ),
				'id'              => 'certificates[socials]',
				'default'         => '',
				'type'            => 'checkbox_list',
				'options'         => array(
					'twitter'  => __( 'Twitter', 'edali-toolkit' ),
					'facebook' => __( 'Facebook', 'edali-toolkit' ),
					'plusone'  => __( 'Plusone', 'edali-toolkit' )
				),
				'select_all_none' => true
			),
			array(
				'name'		=> __( 'Certificate types', 'edali-toolkit' ),
				'id'		=> 'certificates[cer_type]',
				'type'		=> 'radio',
				'options'         => array(
						'canvas'  => __( 'Canvas', 'edali-toolkit' ),
						'image' => __( 'Image', 'edali-toolkit' ),
				),
			),
			array(
				'name'		=> __( 'Fonts directory', 'edali-toolkit' ),
				'id'		=> 'certificates[fonts_dir]',
				'type'		=> 'text',
				'desc' => __('Enter path of fonts folder', 'leanpress-certificates'),
			)
		);
	}
}

return new LP_Certificates_Settings();