<?php

// Box icons
function edali_boxicons() {
    return [
       
        // Box Icons
        'bx bx-info-circle'         => esc_html__( 'Info Circle', 'edali-toolkit' ),
        'bx bx-book-open'           => esc_html__( 'Book Open', 'edali-toolkit' ),
        'bx bx-shopping-bag'        => esc_html__( 'Shopping', 'edali-toolkit' ),
        'bx bxs-badge-dollar'       => esc_html__( 'Dollar', 'edali-toolkit' ),
        'bx bx-code-alt'            => esc_html__( 'Code', 'edali-toolkit' ),
        'bx bx-flag'                => esc_html__( 'Flag', 'edali-toolkit' ),
        'bx bx-camera'              => esc_html__( 'Camera', 'edali-toolkit' ),
        'bx bx-layer'               => esc_html__( 'Layer', 'edali-toolkit' ),
        'bx bxs-flag-checkered'     => esc_html__( 'Flag Checkered', 'edali-toolkit' ),
        'bx bx-health'              => esc_html__( 'Star', 'edali-toolkit' ),
        'bx bx-line-chart'          => esc_html__( 'LLine Chart', 'edali-toolkit' ),
        'bx bx-book-reader'         => esc_html__( 'Book Reader', 'edali-toolkit' ),
        'bx bx-target-lock'         => esc_html__( 'Target Lock', 'edali-toolkit' ),
        'bx bxs-thermometer'        => esc_html__( 'Thermometer', 'edali-toolkit' ),
        'bx bx-shape-triangle'      => esc_html__( 'Triangle', 'edali-toolkit' ),
        'bx bx-font-family'         => esc_html__( 'Font Family', 'edali-toolkit' ),
        'bx bxs-drink'              => esc_html__( 'Drink', 'edali-toolkit' ),
        'bx bx-first-aid'           => esc_html__( 'First Aid', 'edali-toolkit' ),
        'bx bx-bar-chart-alt-2'     => esc_html__( 'Chart', 'edali-toolkit' ),
        'bx bx-briefcase-alt-2'     => esc_html__( 'Briefcase', 'edali-toolkit' ),
        'bx bx-book-reader'         => esc_html__( 'Book Reader', 'edali-toolkit' ),
        'bx bx-target-lock'         => esc_html__( 'Target Lock', 'edali-toolkit' ),
        'bx bx-user-circle'         => esc_html__( 'User', 'edali-toolkit' ),
        'bx bx-check'               => esc_html__( 'Check', 'edali-toolkit' ),
        'bx bx-paper-plane'         => esc_html__( 'Paper Plane', 'edali-toolkit' ),

        // flaticon
        'flaticon-right-arrow'           => esc_html__( 'right-arrow', 'edali-toolkit' ),
        'flaticon-arrows'                => esc_html__( 'arrows', 'edali-toolkit' ),
        'flaticon-diet'                  => esc_html__( 'diet', 'edali-toolkit' ),
        'flaticon-vitamin-c'             => esc_html__( 'vitamin-c', 'edali-toolkit' ),
        'flaticon-heart-rate-monitor'    => esc_html__( 'heart-rate-monitor', 'edali-toolkit' ),
        'flaticon-yoga'                  => esc_html__( 'yoga', 'edali-toolkit' ),
        'flaticon-yoga-1'                => esc_html__( 'yoga-1', 'edali-toolkit' ),
        'flaticon-lotus'                 => esc_html__( 'lotus', 'edali-toolkit' ),
        'flaticon-yoga-2'                => esc_html__( 'yoga-2', 'edali-toolkit' ),
        'flaticon-strawberry'            => esc_html__( 'strawberry', 'edali-toolkit' ),
        'flaticon-tomato'                => esc_html__( 'tomato', 'edali-toolkit' ),
        'flaticon-check'                 => esc_html__( 'check', 'edali-toolkit' ),
        'flaticon-ealthy-food'           => esc_html__( 'ealthy-food', 'edali-toolkit' ),
        'flaticon-pineapple'             => esc_html__( 'pineapple', 'edali-toolkit' ),
        'flaticon-right-quote'           => esc_html__( 'right-quote', 'edali-toolkit' ),
        'flaticon-analytics'             => esc_html__( 'analytics', 'edali-toolkit' ),
        'flaticon-anywhere'              => esc_html__( 'anywhere', 'edali-toolkit' ),
        'flaticon-graduated'             => esc_html__( 'graduated', 'edali-toolkit' ),
        'flaticon-self-improvement'      => esc_html__( 'self-improvement', 'edali-toolkit' ),
        'flaticon-padlock'               => esc_html__( 'padlock', 'edali-toolkit' ),
        'flaticon-launch'                => esc_html__( 'launch', 'edali-toolkit' ),
        'flaticon-self-growth'           => esc_html__( 'self-growth', 'edali-toolkit' ),
        'flaticon-clock'                 => esc_html__( 'clock', 'edali-toolkit' ),
        'flaticon-ebook'                 => esc_html__( 'ebook', 'edali-toolkit' ),
        'flaticon-factory'               => esc_html__( 'factory', 'edali-toolkit' ),
        'flaticon-healthy-food'          => esc_html__( 'factory', 'edali-toolkit' ),
    ];
}

function edali_include_boxicons() {
    return array_keys(edali_boxicons());
}