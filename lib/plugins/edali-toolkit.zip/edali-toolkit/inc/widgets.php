<?php

class edali_posts_thumbs extends WP_Widget{

    function __construct(){
        $widget_ops = array('description' => esc_html__('Display Random or Recent posts with a small image.', 'edali-toolkit'));
        parent::__construct( false, esc_html__('Edali Recent Posts With Image', 'edali-toolkit'), $widget_ops);
    }

    function widget($args, $instance){
        global $edali_theme;
        extract($args); //it receives an associative array

        $title = apply_filters('widget_title', $instance['title']);
        $args = array(
            'posts_per_page' => $instance['number'],
            'post_type' => 'post',
            'order' => 'DESC',
            'orderby' => $instance['orderby']
        );
        $query = new WP_Query($args);

        if( !$query->have_posts() ) return;
        echo $before_widget;
        if($title) echo $before_title.$title.$after_title;
        if(!$instance['number']) $instance['number'] = 4;

        if($query->have_posts()):
            $c = 0;
            
            while($query->have_posts()): $query->the_post(); ?>
                <?php
                $class = 'item';
                $post_id = get_the_ID();
                $thumb_size = 'edali_widget_thumb';
                ?>
                <?php if( !has_post_thumbnail() ) $class .= ' no-thumb'; ?>
                <article <?php post_class($class); ?>>

                    <?php if( has_post_thumbnail() ): ?>
                        <?php
                        $thumb_id   = get_post_thumbnail_id($post_id);
                        $thumb_type = get_post_mime_type($thumb_id);
                        $image_alt  = get_post_meta( $thumb_id, '_wp_attachment_image_alt', true);
                        if( !$image_alt ){
                            $image_alt = get_the_title($post_id);
                        }
                        if($thumb_type == 'image/gif'){
                            $thumb_size = '';
                        }
                        ?>
                        <a href="<?php the_permalink(); ?>" class="thumb hover-effect" aria-label="<?php the_title(); ?>">
                            <?php if( !empty($edali_theme) && $edali_theme['enable_lazyload'] == '1' ): ?>
                                <span class="fullimage cover lazy" role="img" aria-label="<?php echo esc_attr($image_alt); ?>" data-src="<?php the_post_thumbnail_url($thumb_size); ?>"></span>
                            <?php else: ?>
                                <span class="fullimage cover" role="img" aria-label="<?php echo esc_attr($image_alt); ?>" style="background: url('<?php the_post_thumbnail_url($thumb_size); ?>');"></span>
                            <?php endif; ?>
                        </a>
                    <?php endif; ?>

                    <div class="info gradient-effect">
                        <time datetime="<?php the_time('Y-m-d'); ?>"><?php the_time( get_option('date_format') ); ?></time>
                        <h4 class="title usmall"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>								
                    </div>

                    <div class="clear"></div>
                </article>
            <?php
            endwhile;
            wp_reset_postdata();
        endif;
        echo $after_widget;
    }

    function update($new_instance, $old_instance){
        $instance = $old_instance;
        $instance['title'] = strip_tags($new_instance['title']);
        $instance['number'] = (int) $new_instance['number'];
        $instance['orderby'] = $new_instance['orderby'];
        return $instance;
    }

    function form($instance){
        $defaults = array(
            'title' => 'Recent posts',
            'number' => 4,
            'orderby' => 'date'
        );
        $instance = wp_parse_args((array)$instance, $defaults);
        $number = isset( $instance['number'] ) ? absint( $instance['number'] ) : 4;
        ?>
        <p>
            <label for="<?php echo $this->get_field_id('title'); ?>">
                <?php esc_html_e('Title:', 'edali-toolkit'); ?>
                <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $instance['title']; ?>" />
            </label>
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('number'); ?>"><?php esc_html_e( 'Number of posts to show:', 'edali-toolkit'); ?></label>
            <input id="<?php echo $this->get_field_id('number'); ?>" name="<?php echo $this->get_field_name('number'); ?>" type="text" value="<?php echo $number; ?>" size="3" />
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('orderby'); ?>"><?php esc_html_e('Mode:', 'edali-toolkit') ?> </label>
            <select id="<?php echo $this->get_field_id('orderby'); ?>" name="<?php echo $this->get_field_name('orderby'); ?>">
                <option <?php if ($instance['orderby'] == 'date') echo 'selected="selected"'; ?> value="date"><?php esc_html_e('Recent Posts', 'edali-toolkit'); ?></option>
                <option <?php if ($instance['orderby'] == 'rand') echo 'selected="selected"'; ?> value="rand"><?php esc_html_e('Random Posts', 'edali-toolkit'); ?></option>
                <?php if( function_exists('get_field') ): // By views ?>
                    <option <?php if ($instance['orderby'] == 'views') echo 'selected="selected"'; ?> value="views"><?php esc_html_e('Post views', 'edali-toolkit'); ?></option>
                <?php endif; ?>
            </select>
        </p>
        <?php
    }

}

function edali_register_posts_thumbs() {
    register_widget('edali_posts_thumbs');
}

add_action('widgets_init', 'edali_register_posts_thumbs');

/**
 * Contact Info Widget
 */
class edali_contact_info extends WP_Widget{

    function __construct(){
        $widget_ops = array('description' => esc_html__('Display Contact Info', 'edali-toolkit'));
        parent::__construct( false, esc_html__('Edali Contact Info', 'edali-toolkit'), $widget_ops);
    }

    function widget($args, $instance){
        extract($args);
        global $edali_theme;

        $title  = apply_filters('widget_title', $instance['title']);
        $social = ! empty( $instance['social'] ) ? '1' : '0';

        echo $before_widget;
        if($title) echo $before_title.$title.$after_title;
        ?>
        <ul class="contact-us-link">
            <?php if( $instance['location'] != '' ): ?>
                <li>
                    <i class="bx bx-map"></i>
                    <a href="<?php echo esc_url( $instance['location_link'] ); ?>" target="_blank"><?php echo $instance['location']; ?></a>
                </li>
            <?php endif; ?>

            <?php if( $instance['phone'] != '' ): ?>
                <li>
                    <i class="bx bx-phone-call"></i>
                    <a href="<?php echo esc_url( $instance['phone_link'] ); ?>"><?php echo $instance['phone']; ?></a>
                </li>
            <?php endif; ?>

            <?php if( $instance['email'] != '' ): ?>
                <li>
                    <i class="bx bx-envelope"></i>
                    <a href="<?php echo esc_url( $instance['email_link'] ); ?>"><?php echo $instance['email']; ?></a>
                </li>
            <?php endif; ?>
        </ul>
        <?php if ( $social ) { ?>
            <?php edali_social_link(); ?>
        <?php } ?>
        <?php
        echo $after_widget;
    }

    function update($new_instance, $old_instance){
        $instance                    = $old_instance;
        $instance['title']           = strip_tags($new_instance['title']);
        $instance['location']        = $new_instance['location'];
        $instance['location_link']   = $new_instance['location_link'];
        $instance['phone']           = $new_instance['phone'];
        $instance['phone_link']      = $new_instance['phone_link'];
        $instance['email']           = $new_instance['email'];
        $instance['email_link']      = $new_instance['email_link'];
		$instance['social']          = $new_instance['social'] ? 1 : 0;
        return $instance;
    }

    function form($instance){
        $defaults = array(
            'title'             => 'Contact Us',
            'location'          => '2750 Quadra Street Victoria Road, New York, Canada',
            'location_link'     => '#',
            'phone'             => '+1 (123) 456 7890',
            'phone_link'        => 'tel:+11234567890',
            'email'             => 'hello@edali.com',
            'email_link'        => 'mailto:hello@edali.com',
            'social'            => '',
        );
        $instance = wp_parse_args((array)$instance, $defaults);
        ?>
        <p>
            <label for="<?php echo $this->get_field_id('title'); ?>">
                <?php esc_html_e('Title:', 'edali-toolkit'); ?>
                <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $instance['title']; ?>" />
            </label>
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('location'); ?>">
                <?php esc_html_e('Location:', 'edali-toolkit'); ?>
                <input class="widefat" id="<?php echo $this->get_field_id('location'); ?>" name="<?php echo $this->get_field_name('location'); ?>" type="text" value="<?php echo $instance['location']; ?>" />
            </label>
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('location_link'); ?>">
                <?php esc_html_e('Location Link:', 'edali-toolkit'); ?>
                <input class="widefat" id="<?php echo $this->get_field_id('location_link'); ?>" name="<?php echo $this->get_field_name('location_link'); ?>" type="text" value="<?php echo $instance['location_link']; ?>" />
            </label>
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('phone'); ?>">
                <?php esc_html_e('Phone Number:', 'edali-toolkit'); ?>
                <input class="widefat" id="<?php echo $this->get_field_id('phone'); ?>" name="<?php echo $this->get_field_name('phone'); ?>" type="text" value="<?php echo $instance['phone']; ?>" />
            </label>
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('phone_link'); ?>">
                <?php esc_html_e('Number Link:', 'edali-toolkit'); ?>
                <input class="widefat" id="<?php echo $this->get_field_id('phone_link'); ?>" name="<?php echo $this->get_field_name('phone_link'); ?>" type="text" value="<?php echo $instance['phone_link']; ?>" />
            </label>
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('email'); ?>">
                <?php esc_html_e('Email:', 'edali-toolkit'); ?>
                <input class="widefat" id="<?php echo $this->get_field_id('email'); ?>" name="<?php echo $this->get_field_name('email'); ?>" type="text" value="<?php echo $instance['email']; ?>" />
            </label>
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('email_link'); ?>">
                <?php esc_html_e('Email Link:', 'edali-toolkit'); ?>
                <input class="widefat" id="<?php echo $this->get_field_id('email_link'); ?>" name="<?php echo $this->get_field_name('email_link'); ?>" type="text" value="<?php echo $instance['email_link']; ?>" />
            </label>
        </p>
        <p>
			<input class="checkbox" type="checkbox"<?php checked( $instance['social'] ); ?> id="<?php echo $this->get_field_id( 'social' ); ?>" name="<?php echo $this->get_field_name( 'social' ); ?>" /> <label for="<?php echo $this->get_field_id( 'social' ); ?>"><?php _e( 'Display social icons' ); ?></label>
		</p>
        <?php
    }

}

function edali_register_contact_info() {
    register_widget('edali_contact_info');
}

add_action('widgets_init', 'edali_register_contact_info');

/**
 * Footer Newsletter
 */
class edali_newsletter extends WP_Widget{

    function __construct(){
        $widget_ops = array('description' => esc_html__('Display Newsletter', 'edali-toolkit'));
        parent::__construct( false, esc_html__('Edali Newsletter', 'edali-toolkit'), $widget_ops);
    }

    function widget($args, $instance){
        extract($args);
        global $edali_theme;

        $title  = apply_filters('widget_title', $instance['title']);

        echo $before_widget;
        if($title) echo $before_title.$title.$after_title;

        include_once( ABSPATH . 'wp-admin/includes/plugin.php' );

        if ( is_plugin_active( 'newsletter/plugin.php' ) ) {
            ?>
            <div class="newsletter-box">
                <p><?php echo esc_html( $instance['desc'] ); ?></p>

                <form class="newsletter-form" method="post" action="<?php echo home_url(); ?>/?na=s" onsubmit="return newsletter_check(this)">
                    <label><?php echo esc_html( $instance['newsletter_label'] ); ?></label>

                    <input type="email" class="input-newsletter" placeholder="<?php echo esc_attr( $instance['placeholder_text'] ); ?>" name="ne" required>
                    <?php if( $instance['button'] != '' ): ?>
                        <button type="submit"><?php echo esc_html( $instance['button'] ); ?></button>
                    <?php endif; ?>
                </form>
            </div>            
        <?php
        }else {
            echo '<div class="alert alert-danger" role="alert">'.esc_html__( 'Please install and activate Newsletter plugin!', 'edali' ).'</div>';
        }
        echo $after_widget;
    }

    function update($new_instance, $old_instance){
        $instance                       = $old_instance;
        $instance['title']              = strip_tags($new_instance['title']);
        $instance['desc']               = $new_instance['desc'];
        $instance['newsletter_label']   = $new_instance['newsletter_label'];
        $instance['placeholder_text']   = $new_instance['placeholder_text'];
        $instance['button']             = $new_instance['button'];
        return $instance;
    }

    function form($instance){
        $defaults = array(
            'title'             => 'Newsletter',
            'desc'              => 'To get the latest news and latest updates from us.',
            'newsletter_label'  => 'Your e-mail address:',
            'placeholder_text'  => 'Enter your email',
            'button'            => 'Subscribe',
        );
        $instance = wp_parse_args((array)$instance, $defaults);
        ?>
        <p>
            <label for="<?php echo $this->get_field_id('title'); ?>">
                <?php esc_html_e('Title:', 'edali-toolkit'); ?>
                <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $instance['title']; ?>" />
            </label>
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('desc'); ?>">
                <?php esc_html_e('Short Description:', 'edali-toolkit'); ?>
                <input class="widefat" id="<?php echo $this->get_field_id('desc'); ?>" name="<?php echo $this->get_field_name('desc'); ?>" type="text" value="<?php echo $instance['desc']; ?>" />
            </label>
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('newsletter_label'); ?>">
                <?php esc_html_e('From Label:', 'edali-toolkit'); ?>
                <input class="widefat" id="<?php echo $this->get_field_id('newsletter_label'); ?>" name="<?php echo $this->get_field_name('newsletter_label'); ?>" type="text" value="<?php echo $instance['newsletter_label']; ?>" />
            </label>
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('placeholder_text'); ?>">
                <?php esc_html_e('Placeholder Text:', 'edali-toolkit'); ?>
                <input class="widefat" id="<?php echo $this->get_field_id('placeholder_text'); ?>" name="<?php echo $this->get_field_name('placeholder_text'); ?>" type="text" value="<?php echo $instance['placeholder_text']; ?>" />
            </label>
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('button'); ?>">
                <?php esc_html_e('Button Text:', 'edali-toolkit'); ?>
                <input class="widefat" id="<?php echo $this->get_field_id('button'); ?>" name="<?php echo $this->get_field_name('button'); ?>" type="text" value="<?php echo $instance['button']; ?>" />
            </label>
        </p>
        <?php
    }

}

function edali_register_newsletter() {
    register_widget('edali_newsletter');
}

add_action('widgets_init', 'edali_register_newsletter');

/**
 * 
 */
class edali_widget_contact extends WP_Widget{

    function __construct(){
        $widget_ops = array('description' => esc_html__('Display Contact Information', 'edali-toolkit'));
        parent::__construct( false, esc_html__('Edali Contact', 'edali-toolkit'), $widget_ops);
    }

    function widget($args, $instance){
        extract($args);
        global $edali_theme;
        echo $before_widget;
            ?>
            <div class="widget_contact" style="background-image:url(<?php echo esc_url( $instance['bg_image'] ); ?>);">
                <div class="text">
                    <div class="icon">
                        <i class="bx bx-phone-call"></i>
                    </div>
                    <span><?php echo esc_html( $instance['contact_title'] ); ?></span>
                    <a href="<?php echo esc_url( $instance['number_link'] ); ?>"><?php echo esc_html( $instance['number'] ); ?></a>
                </div>
            </div>
        <?php
        echo $after_widget;
    }

    function update($new_instance, $old_instance){
        $instance                           = $old_instance;
        $instance['contact_title']          = $new_instance['contact_title'];
        $instance['bg_image']               = $new_instance['bg_image'];
        $instance['bg_image']               = strip_tags( $new_instance['bg_image'] );
        $instance['number']                 = $new_instance['number'];
        $instance['number_link']            = $new_instance['number_link'];
        return $instance;
    }

    function form($instance){
        $defaults = array(
            'contact_title'         => 'Emergency',
            'number'                => '+0987-9876-8753',
            'number_link'           => 'tel:+0987-9876-8753',
        );
        $instance = wp_parse_args((array)$instance, $defaults);
        ?>
        <p>
            <label for="<?php echo $this->get_field_id('contact_title'); ?>">
                <?php esc_html_e('Title:', 'edali-toolkit'); ?>
                <input class="widefat" id="<?php echo $this->get_field_id('contact_title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $instance['contact_title']; ?>" />
            </label>
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('number'); ?>">
                <?php esc_html_e('Phone Number:', 'edali-toolkit'); ?>
                <input class="widefat" id="<?php echo $this->get_field_id('number'); ?>" name="<?php echo $this->get_field_name('number'); ?>" type="text" value="<?php echo $instance['number']; ?>" />
            </label>
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('number_link'); ?>">
                <?php esc_html_e('Number Link:', 'edali-toolkit'); ?>
                <input class="widefat" id="<?php echo $this->get_field_id('number_link'); ?>" name="<?php echo $this->get_field_name('number_link'); ?>" type="text" value="<?php echo $instance['number_link']; ?>" />
            </label>
        </p>

        <p>
        <label for="<?= $this->get_field_id( 'bg_image' ); ?>">Image</label>
            <img class="<?= $this->id ?>_img" src="<?= (!empty($instance['bg_image'])) ? $instance['bg_image'] : ''; ?>" style="margin:0;padding:0;max-width:100%;display:block"/>
            <input type="text" class="widefat <?= $this->id ?>_url" name="<?= $this->get_field_name( 'bg_image' ); ?>" value="<?= $instance['bg_image']; ?>" style="margin-top:5px;" />
            <input type="button" id="<?= $this->id ?>" class="button button-primary js_custom_upload_media" value="Upload Image" style="margin-top:5px;" />
        </p>

        <script>
            jQuery(document).ready(function ($) {
                function media_upload(button_selector) {
                    var _custom_media = true,
                        _orig_send_attachment = wp.media.editor.send.attachment;
                    $('body').on('click', button_selector, function () {
                    var button_id = $(this).attr('id');
                    wp.media.editor.send.attachment = function (props, attachment) {
                        if (_custom_media) {
                        $('.' + button_id + '_img').attr('src', attachment.url);
                        $('.' + button_id + '_url').val(attachment.url);
                        } else {
                        return _orig_send_attachment.apply($('#' + button_id), [props, attachment]);
                        }
                    }
                    wp.media.editor.open($('#' + button_id));
                    return false;
                    });
                }
                media_upload('.js_custom_upload_media');
                });
        </script>
        
        <?php
    }

}

function edali_register_widget_contact() {
    register_widget('edali_widget_contact');
}

add_action('widgets_init', 'edali_register_widget_contact');