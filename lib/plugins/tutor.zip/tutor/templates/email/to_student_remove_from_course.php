<?php
/**
 * @package TutorLMS/Templates
 * @since 1.6.9
 */

?>

<p>Hi,</p>
<p>
    This is to notify you that the instructor has removed you from the course - <strong>{course_name}</strong>
    <br />
    <br />
    --
    Regards,
    <br />
    {site_name}
</p>

