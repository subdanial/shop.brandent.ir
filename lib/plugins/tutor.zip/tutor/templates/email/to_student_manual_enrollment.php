<?php
/**
 * @package TutorLMS/Templates
 * @version 1.6.9
 */

?>

<p>Hi,</p>
<p>
    Welcome to the course <strong>{course_name}</strong> at {site_url}. You can start learning from here- 
    <br />
    {course_start_url}.
</p>
