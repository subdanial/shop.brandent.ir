<?php
/**
 * @package TutorLMS/Templates
 * @since 1.6.9
 */

?>

<p>Hi,</p>
<p>
    The instructor posted a new announcement on course - <strong>{course_name}</strong>
    <br />
    {announcement}
</p>

