<?php
/**
 * @package TutorLMS/Templates
 * @since 1.6.9
 */

?>

<p>Hi,</p>
<p>
	A new student has signed up to your site <strong>{site_name}</strong>
	<br />
	{student_name}
	<br />
	{student_email}
</p>