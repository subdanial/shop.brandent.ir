<?php
/**
 * @package TutorLMS/Templates
 * @since 1.6.9
 */

?>

<p>Hi,</p>
<p>The grade has been submitted for the assignment <strong>{assignment_name}</strong> for the course <strong>{course_name}</strong></p>
<p>
    Your score: <strong>{assignemnt_score}</strong>
    <br />
    Instructor Comment: {assignment_comment}
</p>
