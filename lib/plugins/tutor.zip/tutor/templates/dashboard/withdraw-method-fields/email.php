<?php
/**
 * @package TutorLMS/Templates
 * @version 1.4.3
 */
?>

<input type="email" name="withdraw_method_field[<?php echo $method_id ?>][<?php echo $field_name ?>]" value="<?php echo $old_value; ?>" >