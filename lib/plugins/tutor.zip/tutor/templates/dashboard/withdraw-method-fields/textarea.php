<?php
/**
 * @package TutorLMS/Templates
 * @version 1.4.3
 */

?>
<textarea name="withdraw_method_field[<?php echo $method_id ?>][<?php echo $field_name ?>]"><?php echo $old_value; ?></textarea>