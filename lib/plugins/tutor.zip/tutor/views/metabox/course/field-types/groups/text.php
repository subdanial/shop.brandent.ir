
<input type="text" name="<?php echo $input_name; ?>" value="<?php echo $input_value; ?>" >
<?php
if ($label){
	echo "<p>{$label}</p>";
}
?>